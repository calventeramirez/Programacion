
package Parcial22_11;


public class T1P3E2{
    public static void main(String[] args) {
       Tablet tableta1 = new Tablet("Lenovo", "E3", 4,12.5 , 500);
       
       tableta1.encenderse();
       tableta1.apagarse();
       tableta1.apagarse();
        System.out.println(tableta1);
    }
}
