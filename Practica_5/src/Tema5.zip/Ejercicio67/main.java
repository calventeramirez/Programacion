
package Ejercicio67;


public class main{
    public static void main(String[] args) {
       Punto p = new Punto(2, 5);
       p.moverHorizontal(5);
       p.mostrar();
       p.moverVertical(-2);
       p.mostrar();
    }
}
