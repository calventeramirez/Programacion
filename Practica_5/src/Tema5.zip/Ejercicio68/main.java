
package Ejercicio68;


public class main{
    public static void main(String[] args) {
       Cafetera cafetera1= new Cafetera();
       
       cafetera1.cantidadCafe();
       cafetera1.llenarCafetera();
       cafetera1.cantidadCafe();
       cafetera1.servirTaza(200);
       cafetera1.cantidadCafe();
       cafetera1.servirTaza(1000);
       cafetera1.cantidadCafe();
    }
}
